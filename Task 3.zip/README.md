This project contains information about the Mandatory Assignment for 02141:

* [Getting started with F# and FSLexYacc](getting-started-fs.md)
* [Getting started with Java and ANLTR4](getting-started-java.md)
* [A simple calculator example](https://gitlab.gbar.dtu.dk/02141/mandatory-assignment/tree/master/calculator)